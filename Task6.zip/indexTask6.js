enabledButton = idButton =>
  document.getElementById(idButton).removeAttribute("disabled");

generateNum = () => Math.random();
setValHTML = (idVal, generateVal) => {
  document.getElementById(idVal).innerHTML = generateVal;
};

getValHTML = idVal => {
  var x = document.getElementById(idVal).innerHTML;
  var y = parseFloat(x);
  return y;
};
startButtonClick = () => {
  var x = generateNum();
  var initialRand2 = "Please select your guess";
  var initialResult = "";
  enabledButton("Bigger");
  enabledButton("Smaller");
  setValHTML("startRand", x);
  setValHTML("predictRand", initialRand2);
  setValHTML("result", initialResult);
};

// count = () => {
//   var counter = 0;
//   if (startButtonClick()) {
//     counter = 1;
//   }
// };
// console.log(document.getElementById("startGame").getAttribute("onclick"));
compareValue = (firstVal, secondVal) => {
  if (firstVal > secondVal) {
    return 0;
  } else if (firstVal <= secondVal) {
    return 1;
  }
};

resultBool = (compareVal, buttonVal) => {
  if (compareVal == buttonVal) {
    return true;
  }
  return false;
};
showResult = (compareVal, buttonVal, secondVal) => {
  if (compareVal == buttonVal) {
    document.getElementById("result").innerHTML = "You guess RIGHT";
    document.getElementById("result").setAttribute("style", "color:green");
    setValHTML("predictRand", secondVal);
  } else {
    document.getElementById("result").innerHTML = "You guess WRONG";
    document.getElementById("result").setAttribute("style", "color:red");
  }
};
buttonValById = id => {
  if (id == "Bigger") {
    return 1;
  } else if (id == "Smaller") {
    return 0;
  }
};

// var counter = 0;
guessCheckButton = id => {
  // console.log(counter);
  // if (counter == 0) {
  var firstVal = getValHTML("startRand");
  console.log("first : ", firstVal);
  var secondVal = generateNum();
  console.log("second: ", secondVal);
  var buttonVal = buttonValById(id);
  var compareVal = compareValue(firstVal, secondVal);
  showResult(compareVal, buttonVal, secondVal);
  // counter++;
  // } else {
  //   console.log("counter", counter);
  //   var buttonVal = buttonValById(id);
  //   var compareVal = compareValue(firstVal, secondVal);
  //   showResult(compareVal, buttonVal, secondVal);
  //   counter++;
  // }
};
